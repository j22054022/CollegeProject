package com.example.test1;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.speech.tts.TextToSpeech;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Button btnDialog;
    private TextView textView;
    private TextToSpeech tts;  //發音模組

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createLanguageTTS();  //建立發音模組
        setContentView(R.layout.activity_main);

        btnDialog = (Button) this.findViewById(R.id.btn1);
        textView = (TextView) this.findViewById(R.id.tv1);

        btnDialog.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                //透過 Intent 的方式開啟內建的語音辨識 Activity...
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "偵測中..."); //語音辨識 Dialog 上要顯示的提示文字

                startActivityForResult(intent, 1);
                //textView.setText("創系宗旨係因應國家資訊與通訊產業之發展需求創系宗旨係因應國家資訊與通訊產業之發展需求創系宗旨係因應國家資訊與通訊產業之發展需求創系宗旨係因應國家資訊與通訊產業之發展需求創系宗旨係因應國家資訊與通訊產業之發展需求");
            }
        });
        /*
        
         */
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                //把所有辨識的可能結果印出來看一看，第一筆是最 match 的。
                ArrayList <String>results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String firstans= ""; //第一個結果
                String all = ""; //所有結果

                for( int i = 0; i < results.size(); i++ )
                {
                    // 一個段落可拆解為多個字組
                    String[] resultWords = results.get(i).split(" ");
                    firstans=resultWords[0]; //第一個結果
                    for( int j = 0; j < resultWords.length; j++ )
                    {
                        all += (i+1) + "."  + resultWords[j] + "\n"; //所有結果
                    }
                }

                // 顯示結果
                textView.setText(firstans);
                //textView.setText(all);
                tts.speak(textView.getText().toString(),TextToSpeech.QUEUE_FLUSH, null );  //將textview內容唸出來
            }
        }
    }
    private void createLanguageTTS() {  //建構TTS
        if( tts == null )
        {
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener(){
                @Override
                public void onInit(int arg0)
                {
                    // TTS 初始化成功
                    if( arg0 == TextToSpeech.SUCCESS )
                    {
                        // 指定的語系: 英文(美國)
                        // Locale l = Locale.US;  // 不要用 Locale.ENGLISH, 會預設用英文(印度)
                        //Locale.TAIWAN(locale.Traditional.Han.Taiwan);
                        // 目前指定的【語系+國家】TTS, 已下載離線語音檔, 可以離線發音
                        if( tts.isLanguageAvailable( Locale.CHINESE ) == TextToSpeech.LANG_COUNTRY_AVAILABLE )
                        {
                            tts.setLanguage(Locale.CHINESE);
                        }
                    }
                }}
            );
        }
    }
    @Override
    protected void onDestroy()
    {
        // 釋放 TTS
        if( tts != null ) tts.shutdown();

        super.onDestroy();
    }
    /*
    public void speak(){
        tts.speak(textView.getText().toString(),TextToSpeech.QUEUE_FLUSH, null );
    }

     */

}

