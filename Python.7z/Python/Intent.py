import random


def weatherIntent(str):
    
    return

def welcomeIntent():
    i=random.randint(0,2)
    if i==0:
        str='你好'
    elif i==1:
        str='嗨'
    else:
        str='哈摟'
    return str

def check(str):
    if '天氣' in str or '氣象' in str:
        return weatherIntent(str)
    elif '嗨' in str or '你好' in str or '哈摟' in str:
        return welcomeIntent(str)
    