from urllib.request import urlopen
html=urlopen("https://www.google.com.tw").read().decode('utf-8')
print(html)