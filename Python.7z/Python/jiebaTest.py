# -*- coding: utf-8 -*-
"""
Created on Tue Jan 14 19:08:01 2020

@author: mark8
"""

import jieba

str = "今天左營區天氣如何"
seg_list=jieba.cut(str,cut_all=False)
print("/".join(seg_list))
print(seg_list)